# from bottle import route, run


# @route('/message')
# def hello():
#     return "Hello from Bottle Application"


# @route('/cars')
# def getcars():
#     cars = [{'name': 'Audi', 'price': 52642},
#             {'name': 'Mercedes', 'price': 57127},
#             {'name': 'Skoda', 'price': 9000},
#             {'name': 'Volvo', 'price': 29000},
#             {'name': 'Bentley', 'price': 350000},
#             {'name': 'Citroen', 'price': 21000},
#             {'name': 'Hummer', 'price': 41400},
#             {'name': 'Volkswagen', 'price': 21600}]
    
#     return dict(data=cars)


# run(host='localhost', port=8080, debug=True, reloader=True)


# ---------------------------------------------------------------

from bottle import route, run, static_file, template, HTTPResponse


@route('/<filepath:path>')
def server_static(filepath):
    return static_file(filepath, root="./public")

@route('/cars')
def check():
    data = getcars()

    if data:
        return template("show_cars", cars=data)
    else:
        return HTTPResponse(status=204)

# DAL
def getcars():
    cars = [{'name': 'Audi', 'price': 52642},
            {'name': 'Mercedes', 'price': 57127},
            {'name': 'Skoda', 'price': 9000},
            {'name': 'Volvo', 'price': 29000},
            {'name': 'Bentley', 'price': 350000},
            {'name': 'Citroen', 'price': 21000},
            {'name': 'Hummer', 'price': 41400},
            {'name': 'Volkswagen', 'price': 21600}]
    
    return cars


run(host='localhost', port=8080, debug=True, reloader=True)
