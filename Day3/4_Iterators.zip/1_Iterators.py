# print("List Iteration")
# l = ["Hello", "to", "everyone"]
# for i in l:
#     print(i)

# print("String Iteration")
# s = "Hello World"
# for i in s:
#     print(i)

# print("Number Iteration") # TypeError: 'int' object is not iterable
# n = 10
# for i in n:
#     print(i)

message = "Hello"

msgIterator = iter(message)
# print(msgIterator)

print(next(msgIterator))
print(next(msgIterator))
print(next(msgIterator))
print(next(msgIterator))
print(next(msgIterator))
# print(next(msgIterator))