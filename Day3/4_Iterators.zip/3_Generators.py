# def myGeneratorFn():
#     yield 1
#     yield 2
#     yield 3

# # for i in myGeneratorFn():
# #     print(i)

# # print(myGeneratorFn())
# x = myGeneratorFn()
# # print(x)

# print(next(x))
# print(next(x))
# print(next(x))

# -------------------------------------


# def fib(n):
#     a, b = 0, 1

#     result = []
#     while a < n:
#         result.append(a)
#         a, b = b, a+b

#     return result

# for r1 in fib(15):
#     print(r1)

def fibGn(n):
    a, b = 0, 1

    while a < n:
        yield a
        a, b = b, a+b


for r1 in fibGn(15):
    print(r1)
