# Create Project Folder
# cd ProjectFolder
# py -m venv myEnv
# myEnv\Scripts\activate
# pip install matplotlib
# pip list
# Create app.py file and write your app code
# py app.py
# pip freeze > requirements.txt
# pip install -r requirements.txt
# myEnv\Scripts\deactivate

from matplotlib import pyplot as plt
import numpy as np

# x = [2, 3, 4, 5, 6]
# y = [20, 30, 40, 50, 10]

# plt.bar(x, y)
# plt.scatter(x, y)
# plt.plot(x, y)
# plt.barh(x, y)


# plt.plot([1, 2, 3, 4])
# plt.plot([1, 2, 3, 4], [1, 4, 9, 16])
# plt.plot([1, 2, 3, 4], [1, 4, 9, 16], 'y--')
# plt.plot([1, 2, 3, 4], [1, 4, 9, 16], 'ro')

# data = np.arange(0., 5., 0.2)
# print(data)

# plt.plot(data, data, 'r--')
# plt.plot(data, data, 'r--', data, data**2, 'bo')
# plt.plot(data, data, 'r--', data, data**2, 'bo', data, data**3, 'ys')

# data = {'a': np.arange(50),
#         'c': np.random.randint(0, 50, 50),
#         'd': np.random.randn(50)}
# data['b'] = data['a'] + 10 * np.random.randn(50)
# data['d'] = np.abs(data['d']) * 100

# plt.scatter('a', 'b', c='c', s='d', data=data)

names = ['group_a', 'group_b', 'group_c']
values = [1, 10, 100]

plt.figure(figsize=(9, 3))

plt.subplot(131)
plt.bar(names, values)
plt.subplot(132)
plt.scatter(names, values)
plt.subplot(133)
plt.plot(names, values)
plt.suptitle('Categorical Plotting')
plt.show()

plt.show()
