# Create Project Folder
# cd ProjectFolder
# py -m venv myEnv
# myEnv\Scripts\activate
# pip install pyodbc
# pip list
# Create app.py file and write your app code
# py app.py
# pip freeze > requirements.txt
# pip install -r requirements.txt
# myEnv\Scripts\deactivate

import pyodbc

conn = pyodbc.connect('Driver={SQL Server};'
                      'Server=.\\SQLEXPRESS;'
                      'Database=Northwind;'
                      'Trusted_Connection=yes;')

cursor = conn.cursor()

rows = cursor.execute('SELECT * FROM Northwind.dbo.Customers')
# print(list(rows))

for row in rows:
    print(row)